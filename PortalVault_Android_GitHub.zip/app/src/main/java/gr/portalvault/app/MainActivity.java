package gr.portalvault.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/** Local-first Android organizer. Does not scrape remote portals or request Internet permission. */
public final class MainActivity extends Activity {
    private static final int IMPORT_FILE=300, EXPORT_FILE=301;
    private static final int BG=Color.rgb(12,16,30), SURFACE=Color.rgb(26,32,53), SURFACE2=Color.rgb(34,41,65);
    private static final int TEXT=Color.rgb(246,246,255), MUTED=Color.rgb(164,174,201), PURPLE=Color.rgb(177,160,255);
    private static final int GREEN=Color.rgb(98,228,173), RED=Color.rgb(255,127,150);
    private EntryStore store;
    private LinearLayout main, body, tabs;
    private TextView stats;
    private int tab=0, visibleCount=100;
    private String chosenId=null, searchQuery="";
    private String exportFormat="json";
    private final Random random=new Random();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        store=new EntryStore(this);
        drawApp();
    }
    private int dp(float px) {return (int)(px*getResources().getDisplayMetrics().density+0.5f);}
    private LinearLayout column() {LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);return c;}
    private LinearLayout row() {LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.HORIZONTAL);c.setGravity(Gravity.CENTER_VERTICAL);return c;}
    private GradientDrawable surface(int bg,int radius) {
        GradientDrawable d=new GradientDrawable();d.setColor(bg);d.setCornerRadius(dp(radius));return d;
    }
    private TextView text(String str,int sp,int color,boolean bold) {
        TextView t=new TextView(this);t.setText(str);t.setTextSize(sp);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);return t;
    }
    private TextView button(String str,int color,int textColor,Runnable action) {
        TextView b=text(str,13,textColor,true);
        b.setGravity(Gravity.CENTER);b.setPadding(dp(14),dp(11),dp(14),dp(11));
        b.setBackground(surface(color,12));b.setClickable(true);
        b.setOnClickListener(v -> action.run());return b;
    }
    private void addSpace(LinearLayout parent,int dp) {
        View spacer=new View(this);parent.addView(spacer,new LinearLayout.LayoutParams(1,dp(dp)));
    }
    private LinearLayout.LayoutParams wrap(int top) {
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(top);return p;
    }
    private void drawApp() {
        main=column();main.setBackgroundColor(BG);
        setContentView(main);
        LinearLayout header=column();header.setPadding(dp(19),dp(18),dp(19),dp(10));main.addView(header);
        LinearLayout headRow=row();header.addView(headRow);
        LinearLayout name=column();headRow.addView(name,new LinearLayout.LayoutParams(0,-2,1f));
        name.addView(text("PORTAL VAULT",22,TEXT,true));
        TextView subtitle=text("Offline organizer  •  Private on-device",11,MUTED,false);name.addView(subtitle);
        headRow.addView(button("＋  Νέα",SURFACE2,TEXT,this::addDialog));
        LinearLayout tools=row();header.addView(tools,wrap(13));
        TextView importButton=button("↥  Import Excel / CSV / JSON",PURPLE,BG,this::openImport);
        tools.addView(importButton,new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-2,-2);ep.leftMargin=dp(9);
        tools.addView(button("↧ Export",SURFACE2,TEXT,this::showExportChoice),ep);
        stats=text("",11,MUTED,false);header.addView(stats,wrap(12));
        HorizontalScrollView tabScroll=new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        main.addView(tabScroll);
        tabs=row();tabs.setPadding(dp(15),dp(8),dp(15),dp(10));tabScroll.addView(tabs);
        ScrollView scroller=new ScrollView(this);scroller.setFillViewport(true);
        main.addView(scroller,new LinearLayout.LayoutParams(-1,0,1f));
        body=column();body.setPadding(dp(18),dp(8),dp(18),dp(24));scroller.addView(body);
        show();
    }
    private void show() {
        int favorites=0, rejected=0, available=0, incomplete=0;
        for(Entry e:store.entries) {
            if(e.vote==1)favorites++;if(e.vote==-1)rejected++;
            if(!e.usable())incomplete++;
            if(e.usable() && e.vote!=-1 && !e.expired())available++;
        }
        stats.setText(store.entries.size()+" εγγραφές  •  "+available+" διαθέσιμες  •  "+favorites+" ♥  •  "+rejected+" ✕  •  "+incomplete+" μόνο ημερομηνίες");
        tabs.removeAllViews();
        String[] tabNames={"Generate","♥ Αγαπημένα","☷ Όλες","✕ Disliked"};
        for(int i=0;i<tabNames.length;i++) {
            final int index=i;
            TextView b=button(tabNames[i],i==tab?PURPLE:SURFACE,i==tab?BG:MUTED,()->{
                tab=index;visibleCount=100;searchQuery="";show();
            });
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.rightMargin=dp(6);tabs.addView(b,p);
        }
        body.removeAllViews();
        if(tab==0) drawGenerate();
        else drawDirectory();
    }
    private List<Entry> candidates() {
        List<Entry> options=new ArrayList<>();
        for(Entry e:store.entries) if(e.usable() && e.vote!=-1 && !e.expired()) options.add(e);
        return options;
    }
    private void generate() {
        List<Entry> options=candidates();
        if(options.isEmpty()) {chosenId=null;show();return;}
        if(options.size()==1)chosenId=options.get(0).id;
        else {
            ArrayList<Entry> alternatives=new ArrayList<>();
            for(Entry e:options)if(!e.id.equals(chosenId))alternatives.add(e);
            chosenId=alternatives.get(random.nextInt(alternatives.size())).id;
        }
        tab=0;show();
    }
    private void drawGenerate() {
        TextView intro=text("ΤΥΧΑΙΑ ΕΠΙΛΟΓΗ",11,PURPLE,true);
        intro.setLetterSpacing(0.12f);body.addView(intro,wrap(6));
        body.addView(text("Βρες την επόμενη εγγραφή",23,TEXT,true),wrap(8));
        body.addView(text("Τα Dislike δεν εμφανίζονται στο Generate. Οι ληγμένες εγγραφές αποκλείονται αυτόματα.",13,MUTED,false),wrap(8));
        TextView generate=button("⤨   GENERATE",PURPLE,BG,this::generate);
        generate.setTextSize(18);generate.setPadding(dp(15),dp(18),dp(15),dp(18));
        body.addView(generate,wrap(20));
        Entry e=chosenId==null?null:store.get(chosenId);
        if(e==null) {
            messageCard("Έτοιμο για Generate",candidates().isEmpty()
                ?"Δεν υπάρχουν ολοκληρωμένες, μη ληγμένες εγγραφές. Κάνε Import από δικό σου Excel, CSV ή JSON ή πρόσθεσε μία χειροκίνητα."
                :"Πάτησε GENERATE για να εμφανιστεί μία εγγραφή.");
        } else drawEntry(e);
        addSpace(body,14);
        body.addView(text("ΛΕΙΤΟΥΡΓΙΑ",11,PURPLE,true),wrap(10));
        body.addView(text("♥ Like → προσθήκη στα Αγαπημένα\n✕ Dislike → κρύβεται από επόμενα Generate\nCopy Both → αντιγράφει Portal και MAC μαζί\nΌλα αποθηκεύονται μόνο στο κινητό.",13,MUTED,false),wrap(8));
    }
    private void messageCard(String heading,String detail) {
        LinearLayout card=column();card.setBackground(surface(SURFACE,18));card.setPadding(dp(19),dp(22),dp(19),dp(22));
        body.addView(card,wrap(17));card.addView(text(heading,17,TEXT,true));card.addView(text(detail,13,MUTED,false),wrap(10));
    }
    private void drawEntry(Entry e) {
        LinearLayout card=column();card.setBackground(surface(SURFACE,20));card.setPadding(dp(17),dp(18),dp(17),dp(18));
        body.addView(card,wrap(15));
        LinearLayout top=row();card.addView(top);
        top.addView(text("ΕΓΓΡΑΦΗ",11,PURPLE,true),new LinearLayout.LayoutParams(0,-2,1f));
        top.addView(text(e.vote==1?"♥ Αγαπημένο":e.vote==-1?"✕ Disliked":"● Ενεργή",11,e.vote==1?GREEN:e.vote==-1?RED:MUTED,true));
        detailLine(card,"PORTAL",e.portal, true);
        detailLine(card,"MAC ADDRESS",e.mac, true);
        detailLine(card,"ΛΗΞΗ",e.dateLabel(),false);
        LinearLayout copies=row();card.addView(copies,wrap(14));
        copies.addView(button("Copy Portal",e.portal.isEmpty()?SURFACE2:PURPLE,e.portal.isEmpty()?MUTED:BG,()->copy(e.portal,"Portal")),new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout.LayoutParams gap=new LinearLayout.LayoutParams(0,-2,1f);gap.leftMargin=dp(8);
        copies.addView(button("Copy MAC",e.mac.isEmpty()?SURFACE2:PURPLE,e.mac.isEmpty()?MUTED:BG,()->copy(e.mac,"MAC")),gap);
        card.addView(button("⧉  COPY BOTH",SURFACE2,TEXT,()->{
            if(!e.complete()){toast("Λείπει Portal ή MAC από την εγγραφή.");return;}
            copy(e.copyBoth(),"Portal + MAC");
        }),wrap(9));
        LinearLayout voting=row();card.addView(voting,wrap(12));
        voting.addView(button(e.vote==1?"♥  Στα Αγαπημένα":"♡  LIKE",e.vote==1?GREEN:SURFACE2,e.vote==1?BG:TEXT,()->vote(e,1)),new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout.LayoutParams d=new LinearLayout.LayoutParams(0,-2,1f);d.leftMargin=dp(9);
        voting.addView(button("✕  DISLIKE",RED,BG,()->vote(e,-1)),d);
        if(!e.source.isEmpty())card.addView(text("Πηγή: "+e.source,11,MUTED,false),wrap(12));
        if(!e.notes.isEmpty())card.addView(text("Σημείωση: "+e.notes,11,MUTED,false),wrap(6));
        if(!e.usable())card.addView(text("Ελλιπής εγγραφή: υπάρχουν μόνο στοιχεία λήξης.",12,RED,false),wrap(8));
    }
    private void detailLine(LinearLayout parent,String label,String value,boolean mono) {
        parent.addView(text(label,11,MUTED,true),wrap(16));
        TextView v=text(value.isEmpty()?"— Δεν έχει καταχωριστεί —":value,mono?15:17,value.isEmpty()?RED:TEXT,true);
        if(mono)v.setTypeface(Typeface.MONOSPACE,Typeface.NORMAL);
        v.setTextIsSelectable(true);parent.addView(v,wrap(5));
    }
    private void vote(Entry e,int value) {
        e.vote = e.vote==value ? 0 : value;
        store.save();
        if(e.vote==-1){chosenId=null;generate();}
        else show();
    }
    private void drawDirectory() {
        String header=tab==1?"Αγαπημένα":tab==2?"Όλες οι εγγραφές":"Disliked εγγραφές";
        body.addView(text(header,23,TEXT,true),wrap(6));
        body.addView(text(tab==3?"Πάτησε Επαναφορά για να συμπεριληφθεί ξανά στο Generate.":"Επίλεξε εγγραφή για προβολή και αντιγραφή.",13,MUTED,false),wrap(8));
        EditText query=new EditText(this);
        query.setTextSize(14);query.setSingleLine(true);query.setTextColor(TEXT);query.setHintTextColor(MUTED);
        query.setHint("Αναζήτηση portal, MAC, λήξης...");query.setPadding(dp(14),dp(10),dp(14),dp(10));
        query.setBackground(surface(SURFACE,12));query.setText(searchQuery);
        body.addView(query,wrap(16));
        LinearLayout results=column();body.addView(results,wrap(12));
        drawRows(results);
        query.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){searchQuery=s.toString();visibleCount=100;drawRows(results);}
            @Override public void afterTextChanged(Editable s){}
        });
    }
    private void drawRows(LinearLayout container) {
        container.removeAllViews();
        List<Entry> filtered=new ArrayList<>();
        String q=searchQuery.trim().toLowerCase(Locale.ROOT);
        for(Entry e:store.entries) {
            if(tab==1 && e.vote!=1)continue;
            if(tab==3 && e.vote!=-1)continue;
            if(!q.isEmpty() && !(e.portal+" "+e.mac+" "+e.expiry+" "+e.notes+" "+e.source).toLowerCase(Locale.ROOT).contains(q))continue;
            filtered.add(e);
        }
        if(tab==1) Collections.reverse(filtered);
        container.addView(text(filtered.size()+" αποτελέσματα",12,MUTED,false));
        if(filtered.isEmpty()) {
            container.addView(text("Δεν βρέθηκαν εγγραφές.",15,MUTED,false),wrap(25));return;
        }
        int count=Math.min(filtered.size(),visibleCount);
        for(int i=0;i<count;i++)drawListRow(container,filtered.get(i));
        if(count<filtered.size()){
            container.addView(button("Περισσότερα  ("+(filtered.size()-count)+" ακόμα)",SURFACE2,TEXT,()->{visibleCount+=100;drawRows(container);}),wrap(14));
        }
    }
    private void drawListRow(LinearLayout container,Entry e) {
        LinearLayout item=column();item.setBackground(surface(SURFACE,14));item.setPadding(dp(13),dp(12),dp(13),dp(12));
        container.addView(item,wrap(9));
        TextView p=text(e.portal.isEmpty()?"Χωρίς Portal":e.portal,13,e.portal.isEmpty()?MUTED:TEXT,true);
        p.setSingleLine();p.setEllipsize(TextUtils.TruncateAt.END);item.addView(p);
        TextView mac=text((e.mac.isEmpty()?"MAC: —":"MAC: "+e.mac)+"     •     "+e.dateLabel(),12,MUTED,false);
        item.addView(mac,wrap(5));
        LinearLayout actions=row();item.addView(actions,wrap(8));
        if(tab==3) {
            actions.addView(button("↺ Επαναφορά",GREEN,BG,()->{e.vote=0;store.save();show();}));
        } else {
            actions.addView(button("Προβολή / Copy",SURFACE2,TEXT,()->{chosenId=e.id;tab=0;show();}));
            if(tab==1){
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.leftMargin=dp(8);
                actions.addView(button("♥ Αφαίρεση",SURFACE2,RED,()->{e.vote=0;store.save();show();}),lp);
            }
        }
    }
    private void copy(String s,String what) {
        if(s==null || s.isEmpty()){toast("Δεν υπάρχει "+what+" στην εγγραφή.");return;}
        ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText(what,s));
        toast("Αντιγράφηκε: "+what);
    }
    private void openImport(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);
        i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/csv","text/plain","application/json","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/octet-stream"});
        startActivityForResult(i,IMPORT_FILE);
    }
    private String filename(Uri uri) {
        String name="file";
        try(Cursor c=getContentResolver().query(uri,null,null,null,null)) {
            if(c!=null && c.moveToFirst()){
                int idx=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if(idx>=0)name=c.getString(idx);
            }
        }catch(Exception ignored){}
        return name;
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(result!=RESULT_OK || data==null || data.getData()==null)return;
        Uri uri=data.getData();
        if(req==IMPORT_FILE){
            try(InputStream in=getContentResolver().openInputStream(uri)){
                if(in==null)throw new IllegalArgumentException("Δεν ήταν δυνατή η ανάγνωση του αρχείου.");
                List<Entry> imported=Importers.parse(in,filename(uri));
                EntryStore.Result r=store.merge(imported);
                new AlertDialog.Builder(this).setTitle("Η εισαγωγή ολοκληρώθηκε")
                    .setMessage("Νέες: "+r.added+"\nΕνημερώθηκαν: "+r.updated+"\nΠαραλείφθηκαν/διπλές: "+r.skipped+"\n\nΟι αξιολογήσεις Like/Dislike διατηρούνται.")
                    .setPositiveButton("OK",(d,w)->show()).show();
            }catch(Exception e){
                new AlertDialog.Builder(this).setTitle("Αποτυχία εισαγωγής")
                    .setMessage(e.getMessage()==null?"Μη αναγνωρίσιμο αρχείο.":e.getMessage()).setPositiveButton("OK",null).show();
            }
        } else if(req==EXPORT_FILE){
            try(OutputStream out=getContentResolver().openOutputStream(uri)){
                if(out==null)throw new IllegalArgumentException("Δεν δημιουργήθηκε το αρχείο.");
                String content=exportFormat.equals("json")?asJson():asCsv();
                out.write(content.getBytes(StandardCharsets.UTF_8));out.flush();
                toast("Η εξαγωγή αποθηκεύτηκε.");
            }catch(Exception e){toast("Αποτυχία εξαγωγής: "+e.getMessage());}
        }
    }
    private void addDialog(){
        LinearLayout fields=column();fields.setPadding(dp(20),dp(4),dp(20),0);
        EditText portal=new EditText(this);portal.setTextSize(14);portal.setHint("Portal URL");portal.setSingleLine(true);fields.addView(portal);
        EditText mac=new EditText(this);mac.setTextSize(14);mac.setHint("MAC Address");mac.setSingleLine(true);fields.addView(mac);
        EditText expiry=new EditText(this);expiry.setTextSize(14);expiry.setHint("Λήξη: 31/12/2027 ή Unlimited");expiry.setSingleLine(true);fields.addView(expiry);
        EditText notes=new EditText(this);notes.setTextSize(14);notes.setHint("Σημειώσεις (προαιρετικό)");fields.addView(notes);
        new AlertDialog.Builder(this).setTitle("Προσθήκη δικής σου εγγραφής")
            .setView(fields).setNegativeButton("Άκυρο",null)
            .setPositiveButton("Αποθήκευση",(d,w)->{
                Entry e=new Entry();e.portal=portal.getText().toString().trim();
                e.mac=Entry.normalizeMac(mac.getText().toString());
                e.expiry=Entry.normalizeExpiry(expiry.getText().toString());
                e.notes=notes.getText().toString().trim();
                if(!e.usable()){toast("Χρειάζεται τουλάχιστον Portal ή MAC.");return;}
                List<Entry> list=new ArrayList<>();list.add(e);
                EntryStore.Result result=store.merge(list);
                toast(result.added>0?"Η εγγραφή αποθηκεύτηκε.":"Η υπάρχουσα εγγραφή ενημερώθηκε.");
                show();
            }).show();
    }
    private void showExportChoice(){
        new AlertDialog.Builder(this).setTitle("Εξαγωγή τοπικών εγγραφών")
            .setMessage("Το αρχείο μπορεί να περιέχει ιδιωτικά στοιχεία πρόσβασης. Μην το ανεβάσεις σε δημόσιο GitHub repository.")
            .setItems(new String[]{"JSON (πλήρες αντίγραφο)","CSV (συμβατό με Excel)"},(d,which)->{
                exportFormat=which==0?"json":"csv";
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(exportFormat.equals("json")?"application/json":"text/csv");
                i.putExtra(Intent.EXTRA_TITLE,"portal-vault-backup."+exportFormat);
                startActivityForResult(i,EXPORT_FILE);
            }).setNegativeButton("Άκυρο",null).show();
    }
    private String asJson()throws Exception{
        JSONArray a=new JSONArray();for(Entry e:store.entries)a.put(e.toJson());return a.toString(2);
    }
    private String asCsv(){
        StringBuilder s=new StringBuilder("\uFEFFportal,mac,expiry,source,notes,vote\r\n");
        for(Entry e:store.entries){
            String[] cells={e.portal,e.mac,e.expiry,e.source,e.notes,String.valueOf(e.vote)};
            for(int i=0;i<cells.length;i++){
                if(i>0)s.append(',');s.append('"').append(cells[i].replace("\"","\"\"")).append('"');
            }
            s.append("\r\n");
        }
        return s.toString();
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
