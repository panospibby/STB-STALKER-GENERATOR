package gr.portalvault.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class EntryStore {
    private static final String PREFERENCES = "portal_vault_local_v1";
    private final Context context;
    private final SharedPreferences prefs;
    public final ArrayList<Entry> entries = new ArrayList<>();

    EntryStore(Context ctx) {
        context = ctx.getApplicationContext();
        prefs = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE);
        load();
    }
    void load() {
        try {
            if (!prefs.getBoolean("initialized", false)) {
                try (InputStream in = context.getAssets().open("seed.json")) {
                    String raw = readAll(in);
                    JSONArray a = new JSONArray(raw);
                    for (int i=0; i<a.length(); i++) entries.add(Entry.fromJson(a.getJSONObject(i)));
                }
                save();
                return;
            }
            JSONArray a = new JSONArray(prefs.getString("entries", "[]"));
            for (int i=0; i<a.length(); i++) entries.add(Entry.fromJson(a.getJSONObject(i)));
        } catch (Exception e) { throw new IllegalStateException("Cannot load local entries", e); }
    }
    void save() {
        JSONArray a = new JSONArray();
        for (Entry e : entries) {
            try { a.put(e.toJson()); } catch (Exception ignored) {}
        }
        if (!prefs.edit().putString("entries", a.toString()).putBoolean("initialized", true).commit()) {
            throw new IllegalStateException("Could not persist local database");
        }
    }
    public Entry get(String id) {
        for (Entry e : entries) if (e.id.equals(id)) return e;
        return null;
    }
    public Result merge(List<Entry> incoming) {
        Map<String, Entry> byKey = new HashMap<>();
        for (Entry e : entries) if (e.usable()) byKey.put(e.identity(), e);
        Result result = new Result();
        for (Entry e : incoming) {
            if (!e.usable()) { result.skipped++; continue; }
            e.mac = Entry.normalizeMac(e.mac);
            Entry existing = byKey.get(e.identity());
            if (existing == null) {
                entries.add(e);
                byKey.put(e.identity(), e);
                result.added++;
            } else {
                boolean changed = false;
                if (!e.expiry.isEmpty() && !e.expiry.equals(existing.expiry)) { existing.expiry = e.expiry; changed = true; }
                if (!e.source.isEmpty() && !e.source.equals(existing.source)) { existing.source = e.source; changed = true; }
                if (!e.notes.isEmpty() && !e.notes.equals(existing.notes)) { existing.notes = e.notes; changed = true; }
                if (changed) result.updated++; else result.skipped++;
                // Intentionally preserve existing Like / Dislike status on re-import.
            }
        }
        save();
        return result;
    }
    public static String readAll(InputStream input) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int n;
        while ((n = input.read(buffer)) != -1) out.write(buffer, 0, n);
        return out.toString(StandardCharsets.UTF_8.name());
    }
    static final class Result {
        int added, updated, skipped;
    }
}
