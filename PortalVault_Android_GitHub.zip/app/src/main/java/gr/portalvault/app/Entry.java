package gr.portalvault.app;

import org.json.JSONException;
import org.json.JSONObject;
import java.text.Normalizer;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Locale;
import java.util.UUID;

public final class Entry {
    public String id = UUID.randomUUID().toString();
    public String portal = "";
    public String mac = "";
    public String expiry = "";
    public String source = "";
    public String notes = "";
    public String originKey = "";
    public int vote = 0; // -1 excluded, 0 neutral, 1 favorite

    public static Entry fromJson(JSONObject j) {
        Entry e = new Entry();
        e.id = j.optString("id", e.id);
        e.portal = field(j, "portal", "portalUrl", "portal_url", "server", "url", "host");
        e.mac = field(j, "mac", "macAddress", "mac_address", "macaddress");
        e.expiry = normalizeExpiry(field(j, "expiry", "expires", "expiration", "expirationDate", "expiration_date", "endDate", "end_date"));
        e.source = field(j, "source", "sourceUrl", "source_url");
        e.notes = field(j, "notes", "note", "comment");
        e.originKey = j.optString("originKey", "");
        e.vote = Math.max(-1, Math.min(1, j.optInt("vote", 0)));
        return e;
    }

    static String field(JSONObject j, String... keys) {
        for (String key : keys) {
            Object v = j.opt(key);
            if (v != null && v != JSONObject.NULL && !String.valueOf(v).trim().isEmpty()) {
                return String.valueOf(v).trim();
            }
        }
        return "";
    }

    public JSONObject toJson() throws JSONException {
        JSONObject j = new JSONObject();
        j.put("id", id);
        j.put("portal", portal);
        j.put("mac", mac);
        j.put("expiry", expiry);
        j.put("source", source);
        j.put("notes", notes);
        j.put("originKey", originKey);
        j.put("vote", vote);
        return j;
    }

    public boolean complete() { return !portal.trim().isEmpty() && !mac.trim().isEmpty(); }
    public boolean usable() { return !portal.trim().isEmpty() || !mac.trim().isEmpty(); }
    public boolean expired() {
        LocalDate d = date();
        return d != null && d.isBefore(LocalDate.now());
    }
    public LocalDate date() {
        try { return LocalDate.parse(expiry); } catch (Exception ignored) { return null; }
    }
    public String dateLabel() {
        if (expiry.isEmpty()) return "Άγνωστη λήξη";
        if (expiry.equalsIgnoreCase("Unlimited")) return "Unlimited";
        LocalDate d = date();
        return d == null ? expiry : d.format(DateTimeFormatter.ofPattern("dd/MM/uuuu"));
    }
    public String copyBoth() {
        return "Portal: " + portal + "\nMAC: " + mac;
    }
    public String identity() {
        if (usable()) return portal.trim().toLowerCase(Locale.ROOT) + "|" + normalizeMac(mac);
        return !originKey.isEmpty() ? "origin:" + originKey : "empty:" + source + "|" + expiry;
    }
    public static String normalizeMac(String input) {
        String t = input == null ? "" : input.trim().replace('-', ':').toUpperCase(Locale.ROOT);
        if (t.matches("[A-F0-9]{12}")) {
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < 12; i += 2) { if (i > 0) b.append(':'); b.append(t, i, i+2); }
            return b.toString();
        }
        return t;
    }
    public static String normalizeExpiry(String input) {
        if (input == null) return "";
        String s = input.trim();
        if (s.isEmpty()) return "";
        String lower = Normalizer.normalize(s.toLowerCase(Locale.ROOT), Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        if (lower.contains("unlimited") || lower.contains("lifetime") || lower.contains("απεριορισ")) return "Unlimited";
        String[] formats = {"uuuu-MM-dd", "d/M/uuuu", "dd/MM/uuuu", "d.M.uuuu", "dd.MM.uuuu", "d-M-uuuu", "dd-MM-uuuu", "uuuu/MM/dd", "uuuu-MM-dd HH:mm:ss", "dd/MM/uuuu HH:mm:ss"};
        for (String f : formats) {
            try {
                DateTimeFormatter fmt = DateTimeFormatter.ofPattern(f, Locale.ROOT);
                LocalDate date = f.contains("HH") ? java.time.LocalDateTime.parse(s, fmt).toLocalDate() : LocalDate.parse(s, fmt);
                return date.toString();
            } catch (DateTimeParseException ignored) {}
        }
        if (s.matches("\\d+(\\.\\d+)?")) {
            try {
                double serial = Double.parseDouble(s);
                if (serial > 20000 && serial < 150000) return LocalDate.of(1899, 12, 30).plusDays((long) Math.floor(serial)).toString();
            } catch (Exception ignored) {}
        }
        return s;
    }
}
