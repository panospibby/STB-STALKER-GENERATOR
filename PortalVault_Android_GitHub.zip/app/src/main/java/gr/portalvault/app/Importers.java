package gr.portalvault.app;

import android.util.Xml;
import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Offline, dependency-free CSV / JSON / XLSX reader; no remote network access. */
public final class Importers {
    private static final int MAX_BYTES = 28 * 1024 * 1024;
    private Importers() {}

    public static List<Entry> parse(InputStream stream, String filename) throws Exception {
        byte[] bytes = limitedRead(stream);
        String name = filename == null ? "" : filename.toLowerCase(Locale.ROOT);
        if (name.endsWith(".xls")) throw new IllegalArgumentException("Το παλιό .xls δεν υποστηρίζεται. Αποθήκευσέ το ως .xlsx ή .csv.");
        if ((bytes.length > 2 && bytes[0] == 'P' && bytes[1] == 'K') || name.endsWith(".xlsx")) return parseXlsx(bytes);
        String text = new String(bytes, StandardCharsets.UTF_8);
        if (text.startsWith("\uFEFF")) text = text.substring(1);
        String trimmed = text.trim();
        if (name.endsWith(".json") || trimmed.startsWith("[") || trimmed.startsWith("{")) return parseJson(trimmed);
        return tableToEntries(parseDelimited(text));
    }

    private static byte[] limitedRead(InputStream stream) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192]; int n;
        while ((n=stream.read(buffer)) != -1) {
            if (out.size()+n > MAX_BYTES) throw new IllegalArgumentException("Το αρχείο είναι μεγαλύτερο από 28 MB.");
            out.write(buffer,0,n);
        }
        return out.toByteArray();
    }

    private static List<Entry> parseJson(String raw) throws Exception {
        Object root = new org.json.JSONTokener(raw).nextValue();
        JSONArray rows;
        if (root instanceof JSONArray) rows = (JSONArray) root;
        else if (root instanceof JSONObject) {
            JSONObject j = (JSONObject) root;
            rows = j.optJSONArray("entries");
            if (rows == null) rows = j.optJSONArray("records");
            if (rows == null) rows = j.optJSONArray("items");
            if (rows == null) rows = j.optJSONArray("data");
            if (rows == null) { rows = new JSONArray(); rows.put(j); }
        } else throw new IllegalArgumentException("Μη αναγνωρίσιμη δομή JSON.");
        List<Entry> out = new ArrayList<>();
        for (int i=0;i<rows.length();i++) {
            JSONObject obj = rows.optJSONObject(i);
            if (obj == null) continue;
            Entry e = fromMapJson(obj);
            if (e.usable()) out.add(e);
        }
        return out;
    }
    private static Entry fromMapJson(JSONObject obj) {
        Entry e = Entry.fromJson(obj);
        // Permit locale-specific keys and a common exported CSV schema.
        java.util.Iterator<String> it = obj.keys();
        while (it.hasNext()) {
            String key = it.next();
            String val = obj.optString(key, "").trim();
            switch (columnType(key)) {
                case "portal": if(e.portal.isEmpty()) e.portal=val; break;
                case "mac": if(e.mac.isEmpty()) e.mac=val; break;
                case "expiry": if(e.expiry.isEmpty()) e.expiry=Entry.normalizeExpiry(val); break;
                case "source": if(e.source.isEmpty()) e.source=val; break;
                case "notes": if(e.notes.isEmpty()) e.notes=val; break;
            }
        }
        e.mac = Entry.normalizeMac(e.mac);
        // JSON backups may include vote=-1/0/1, allowing preference recovery.
        e.id = java.util.UUID.randomUUID().toString();
        return e;
    }

    private static List<List<String>> parseDelimited(String text) {
        String first = text.split("\\r?\\n",2)[0];
        char delimiter = detectDelimiter(first);
        List<List<String>> rows = new ArrayList<>();
        List<String> row = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        boolean quoted = false;
        for (int i=0; i<text.length(); i++) {
            char ch=text.charAt(i);
            if (ch=='"') {
                if (quoted && i+1<text.length() && text.charAt(i+1)=='"') { cell.append('"'); i++; }
                else quoted = !quoted;
            } else if (ch==delimiter && !quoted) {
                row.add(cell.toString().trim()); cell.setLength(0);
            } else if ((ch=='\n' || ch=='\r') && !quoted) {
                if (ch=='\r' && i+1<text.length() && text.charAt(i+1)=='\n') i++;
                row.add(cell.toString().trim()); cell.setLength(0);
                if (!allEmpty(row)) rows.add(row);
                row=new ArrayList<>();
            } else cell.append(ch);
        }
        row.add(cell.toString().trim());
        if (!allEmpty(row)) rows.add(row);
        return rows;
    }
    private static char detectDelimiter(String line) {
        int commas=0, semis=0, tabs=0; boolean quoted=false;
        for(int i=0;i<line.length();i++) {
            char c=line.charAt(i);
            if(c=='"') quoted=!quoted;
            else if(!quoted) { if(c==',') commas++; if(c==';') semis++; if(c=='\t') tabs++; }
        }
        if(tabs>=commas && tabs>=semis && tabs>0) return '\t';
        return semis>commas ? ';' : ',';
    }
    private static boolean allEmpty(List<String> fields) {
        for(String s:fields) if(!s.isEmpty()) return false;
        return true;
    }

    private static List<Entry> parseXlsx(byte[] zipBytes) throws Exception {
        byte[] shared=null;
        Map<String,byte[]> sheets=new HashMap<>();
        try(ZipInputStream zin=new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
            ZipEntry ze;
            byte[] buf=new byte[8192];
            while ((ze=zin.getNextEntry())!=null) {
                String name=ze.getName();
                boolean isSheet=name.matches("xl/worksheets/sheet[0-9]+\\.xml");
                boolean isShared=name.equals("xl/sharedStrings.xml");
                if (!isSheet && !isShared) continue;
                ByteArrayOutputStream out=new ByteArrayOutputStream(); int n;
                while((n=zin.read(buf))!=-1) {
                    if(out.size()+n > MAX_BYTES) throw new IllegalArgumentException("Υπερβολικά μεγάλο φύλλο Excel.");
                    out.write(buf,0,n);
                }
                if(isShared) shared=out.toByteArray();
                if(isSheet) sheets.put(name,out.toByteArray());
            }
        }
        if(sheets.isEmpty()) throw new IllegalArgumentException("Δεν βρέθηκε φύλλο εργασίας στο .xlsx.");
        List<String> strings=shared==null?Collections.emptyList():readSharedStrings(shared);
        List<String> names=new ArrayList<>(sheets.keySet());
        Collections.sort(names,(a,b)->Integer.compare(sheetNumber(a),sheetNumber(b)));
        List<Entry> combined=new ArrayList<>();
        for(String name:names) combined.addAll(tableToEntries(readSheet(sheets.get(name),strings)));
        return combined;
    }
    private static int sheetNumber(String name) {
        try {return Integer.parseInt(name.replaceAll("[^0-9]",""));}
        catch(Exception ignored){return Integer.MAX_VALUE;}
    }
    private static XmlPullParser xml(byte[] bytes) throws Exception {
        String str=new String(bytes,StandardCharsets.UTF_8);
        if(str.contains("<!DOCTYPE") || str.contains("<!ENTITY")) throw new IllegalArgumentException("Unsupported XML entity declaration.");
        XmlPullParser p=Xml.newPullParser();
        p.setInput(new InputStreamReader(new ByteArrayInputStream(bytes),StandardCharsets.UTF_8));
        return p;
    }
    private static List<String> readSharedStrings(byte[] bytes) throws Exception {
        List<String> strings=new ArrayList<>();
        XmlPullParser p=xml(bytes);
        boolean inSi=false;
        StringBuilder val=new StringBuilder();
        for(int event=p.getEventType(); event!=XmlPullParser.END_DOCUMENT; event=p.next()) {
            if(event==XmlPullParser.START_TAG) {
                String tag=p.getName();
                if(tag.equals("si")) {inSi=true;val.setLength(0);}
                else if(tag.equals("t") && inSi) val.append(p.nextText());
            } else if(event==XmlPullParser.END_TAG && p.getName().equals("si")) {
                strings.add(val.toString());inSi=false;
            }
        }
        return strings;
    }
    private static List<List<String>> readSheet(byte[] sheet,List<String> shared) throws Exception {
        List<List<String>> rows=new ArrayList<>();
        XmlPullParser p=xml(sheet);
        Map<Integer,String> values=new HashMap<>();
        boolean inRow=false,inCell=false;
        int col=0, sequential=0; String cellType="",cellValue="";
        for(int event=p.getEventType();event!=XmlPullParser.END_DOCUMENT;event=p.next()) {
            if(event==XmlPullParser.START_TAG) {
                String tag=p.getName();
                if(tag.equals("row")) {inRow=true;values.clear();sequential=0;}
                else if(tag.equals("c") && inRow) {
                    inCell=true;cellValue="";
                    cellType=p.getAttributeValue(null,"t");
                    String address=p.getAttributeValue(null,"r");
                    col=address==null?sequential:columnIndex(address);
                    sequential=col+1;
                } else if(inCell && tag.equals("v")) cellValue=p.nextText();
                else if(inCell && tag.equals("t") && "inlineStr".equals(cellType)) cellValue+=p.nextText();
            } else if(event==XmlPullParser.END_TAG) {
                String tag=p.getName();
                if(tag.equals("c") && inCell) {
                    if("s".equals(cellType)) {
                        try {cellValue=shared.get(Integer.parseInt(cellValue.trim()));}catch(Exception ignored){cellValue="";}
                    }
                    if(col>=0 && col<256) values.put(col,cellValue);
                    inCell=false;
                } else if(tag.equals("row") && inRow) {
                    if(!values.isEmpty()) {
                        int max=Collections.max(values.keySet());
                        List<String> row=new ArrayList<>();
                        for(int i=0;i<=max;i++)row.add(values.getOrDefault(i,"").trim());
                        if(!allEmpty(row))rows.add(row);
                    }
                    inRow=false;
                }
            }
        }
        return rows;
    }
    private static int columnIndex(String ref) {
        int c=0;
        for(int i=0;i<ref.length();i++) {
            char x=Character.toUpperCase(ref.charAt(i));
            if(x<'A'||x>'Z')break;
            c=c*26+(x-'A'+1);
        }
        return Math.max(0,c-1);
    }
    private static List<Entry> tableToEntries(List<List<String>> rows) {
        List<Entry> out=new ArrayList<>();
        if(rows.isEmpty()) return out;
        int headerRow=-1;
        Map<String,Integer> index=new HashMap<>();
        for(int r=0;r<Math.min(rows.size(),8);r++) {
            Map<String,Integer> test=new HashMap<>();
            for(int c=0;c<rows.get(r).size();c++) {
                String key=columnType(rows.get(r).get(c));
                if(!key.isEmpty()) test.putIfAbsent(key,c);
            }
            if(test.containsKey("portal") || test.containsKey("mac")) {
                index=test;headerRow=r;break;
            }
        }
        if(headerRow==-1) {
            // CSV without a heading row: positional Portal, MAC, Expiry, Source, Notes.
            index.put("portal",0); index.put("mac",1); index.put("expiry",2);
            index.put("source",3); index.put("notes",4);
        }
        for(int r=headerRow+1;r<rows.size();r++) {
            List<String> cols=rows.get(r);
            Entry e=new Entry();
            e.portal=at(cols,index.get("portal"));
            e.mac=Entry.normalizeMac(at(cols,index.get("mac")));
            e.expiry=Entry.normalizeExpiry(at(cols,index.get("expiry")));
            e.source=at(cols,index.get("source"));
            e.notes=at(cols,index.get("notes"));
            if(e.usable())out.add(e);
        }
        return out;
    }
    private static String at(List<String> row,Integer i) {return i!=null && i>=0 && i<row.size()?row.get(i).trim():"";}
    private static String columnType(String key) {
        if(key==null) return "";
        String k=Normalizer.normalize(key.toLowerCase(Locale.ROOT).trim(),Normalizer.Form.NFD).replaceAll("\\p{M}","");
        k=k.replaceAll("[^a-z0-9α-ω]", "");
        if(k.equals("portal")||k.equals("portalurl")||k.equals("portallink")||k.equals("server")||k.equals("serverurl")||k.equals("host")||k.equals("stalkerportal")||k.equals("url")||k.equals("πορταλ")||k.equals("διευθυνσηportal")) return "portal";
        if(k.equals("mac")||k.equals("macaddress")||k.equals("macaddr")||k.equals("deviceid")||k.equals("μακ")||k.equals("διευθυνσηmac")) return "mac";
        if(k.equals("expiry")||k.equals("expires")||k.equals("expiration")||k.equals("expirationdate")||k.equals("expirydate")||k.equals("enddate")||k.equals("expirytime")||k.equals("ληξη")||k.equals("ημερομηνιαληξης")||k.equals("ημερομηνια")||k.equals("validuntil")) return "expiry";
        if(k.equals("source")||k.equals("sourceurl")||k.equals("πηγη")||k.equals("linkπηγης")) return "source";
        if(k.equals("notes")||k.equals("note")||k.equals("comments")||k.equals("comment")||k.equals("σημειωσεις")||k.equals("σχολια")) return "notes";
        return "";
    }
}
